"""PokerBot — `decide(game_state) -> dict`.

Schema and return shapes are documented in `docs/api-cheatsheet.md`; ground
truth lives in `ext/fullhouse-engine/sandbox/validator.py::TEST_STATES`.

The shipped archive places a tiny shim at `bot.py` (archive root) that does
`from src.bot import decide`. Heavy loads (blueprints, eval7 LUTs) happen at
module import — the engine's one-shot 30 s warmup call covers them so live
2 s decisions stay fast.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

DATA_DIR = os.environ.get(
    "BOT_DATA_DIR",
    os.path.join(os.path.dirname(_HERE), "data"),
)

try:
    from src.opponent_model import OpponentModel
    from src.preflop_lookup import lookup as _preflop_lookup
    from src.postflop import decide_postflop as _decide_postflop
    from src.ranges import canonical_hand, hand_score
    from src.sizing import sizing_to_amount
    from src.timeout_guard import run_with_budget
except ImportError:  # direct runner load from src/bot.py
    from opponent_model import OpponentModel
    from preflop_lookup import lookup as _preflop_lookup
    from postflop import decide_postflop as _decide_postflop
    from ranges import canonical_hand, hand_score
    from sizing import sizing_to_amount
    from timeout_guard import run_with_budget

_VALID_ACTIONS = {"fold", "check", "call", "raise", "all_in"}
_OVERLAY_DISABLED = os.environ.get("POKERBOT_DISABLE_OVERLAY") == "1"
_OPPONENT_MODEL = OpponentModel()

_OPEN_EDGE_SCORE = hand_score("T8s")
_CONTINUE_EDGE_MARGIN = 1
_CONTINUE_EDGE_SCORE = hand_score("KTo") + _CONTINUE_EDGE_MARGIN
_SCORE_POINTS_PER_DEVIATION_PP = 1.0
_ARCHETYPE_SHIFT_WEIGHTS = {
    "range_mc_pot_odds": {"open": 0.60, "continue": 0.40},
    "blueprint_threshold_exploit": {"open": 0.20, "continue": 0.80},
    "risk_gated_conservative": {"open": -1.00, "continue": 0.00},
    "stage_variant_anti_punt": {"open": -0.25, "continue": 0.50},
    "monte_carlo_basic": {"open": 0.40, "continue": 0.60},
}


def _safe_fallback(game_state: dict) -> dict:
    """Last-resort legal action. Never raises."""
    if isinstance(game_state, dict) and game_state.get("can_check"):
        return {"action": "check"}
    return {"action": "fold"}


def _legalize_action(game_state: dict, raw_action: dict) -> dict:
    """Normalize strategy output to one of the engine's valid action shapes."""
    # Source: [[Engine-Fullhouse]]
    if not isinstance(game_state, dict) or not isinstance(raw_action, dict):
        return _safe_fallback(game_state)

    action = str(raw_action.get("action", "")).lower().strip()
    if action not in _VALID_ACTIONS:
        return _safe_fallback(game_state)

    if action == "check":
        if game_state.get("can_check"):
            return {"action": "check"}
        return {"action": "call"}

    if action == "call":
        if game_state.get("can_check"):
            return {"action": "check"}
        return {"action": "call"}

    if action == "raise":
        try:
            amount = int(raw_action.get("amount"))
        except (TypeError, ValueError):
            return _safe_fallback(game_state)
        min_raise_to = int(game_state.get("min_raise_to") or 0)
        stack_total = int(game_state.get("your_stack") or 0) + int(
            game_state.get("your_bet_this_street") or 0
        )
        if stack_total <= 0:
            return _safe_fallback(game_state)
        amount = max(amount, min_raise_to)
        if amount >= stack_total:
            return {"action": "all_in"}
        return {"action": "raise", "amount": amount}

    if action == "all_in":
        return {"action": "all_in"}

    return {"action": "fold"}


def _decide_core(game_state: dict) -> dict:
    """Fast deterministic baseline. Later gates refine the table and overlay."""
    street = game_state.get("street")
    if street == "preflop":
        return _decide_preflop(game_state)
    if street in ("flop", "turn", "river"):
        return _decide_postflop(game_state)
    return _safe_fallback(game_state)


def _position_label(game_state: dict) -> str:
    players = game_state.get("players") or []
    seat = int(game_state.get("seat_to_act") or 0)
    if len(players) == 2:
        if game_state.get("street") == "preflop":
            voluntary = [
                item.get("action")
                for item in game_state.get("action_log") or []
                if isinstance(item, dict) and item.get("action") not in ("small_blind", "big_blind")
            ]
            if not voluntary and not game_state.get("can_check"):
                return "heads_up_button"
            return "big_blind"
        return "heads_up_button" if seat == 0 else "big_blind"
    if len(players) >= 2 and seat >= len(players) - 2:
        return "button"
    if seat <= 1:
        return "early"
    return "middle"


def _action_sequence(game_state: dict) -> tuple:
    actions = []
    for item in game_state.get("action_log") or []:
        action = item.get("action") if isinstance(item, dict) else None
        if action:
            actions.append(str(action).lower())
    return tuple(actions)


def _decide_preflop(game_state: dict) -> dict:
    hand = canonical_hand(game_state.get("your_cards") or [])
    position = _position_label(game_state)
    action_seq = _action_sequence(game_state)
    decision = _preflop_lookup(position, hand, action_seq)
    if not _OVERLAY_DISABLED:
        overlay = _pressure_preflop_overlay(game_state, hand, decision, action_seq)
        if overlay is not None:
            return overlay
    return _preflop_action_from_decision(game_state, decision)


def _preflop_action_from_decision(game_state: dict, decision: dict | None) -> dict:
    if not decision:
        return _safe_fallback(game_state)

    action = decision.get("action")
    if action != "raise":
        return {"action": action}

    amount = decision.get("amount")
    if amount is None:
        amount = sizing_to_amount(
            decision.get("sizing", "min_raise"),
            game_state.get("pot", 0),
            game_state.get("your_stack", 0),
            game_state.get("min_raise_to", 0),
            game_state.get("your_bet_this_street", 0),
        )
    return {"action": "raise", "amount": amount}


def _pressure_preflop_overlay(
    game_state: dict,
    hand: str,
    blueprint_decision: dict | None = None,
    action_seq: tuple | None = None,
):
    """Apply a posterior-weighted, tightly bounded preflop refinement."""
    # Source: [[Libratus-Brown-Sandholm-2017]]
    features = _OPPONENT_MODEL.archetype_features(game_state)
    shifts = _posterior_preflop_deviation(features)
    if shifts["deviation_bound_pp"] <= 0.0:
        return None
    if abs(shifts["open_shift_pp"]) + abs(shifts["continue_shift_pp"]) < 0.75:
        return None

    if blueprint_decision is None:
        blueprint_decision = _preflop_lookup(
            _position_label(game_state),
            hand,
            action_seq if action_seq is not None else _action_sequence(game_state),
        )
    if not blueprint_decision:
        return None

    action = blueprint_decision.get("action")
    reason = blueprint_decision.get("reason")
    score = hand_score(hand)
    facing_raise = bool(features.get("facing_raise"))

    if facing_raise:
        if (
            shifts["continue_shift_pp"] > 0.0
            and action == "call"
            and reason == "priced_continue"
            and _within_shift(score, _CONTINUE_EDGE_SCORE, shifts["continue_shift_pp"])
        ):
            return _safe_fallback(game_state)
        return None

    if action == "fold" and reason == "range_fold" and shifts["open_shift_pp"] < 0.0:
        if _within_shift(score, _OPEN_EDGE_SCORE, -shifts["open_shift_pp"]):
            return _min_raise_action(game_state)

    if action == "raise" and reason == "range_open" and shifts["open_shift_pp"] > 0.0:
        if _within_shift(score, _OPEN_EDGE_SCORE, shifts["open_shift_pp"]):
            return _safe_fallback(game_state)

    return None


def _posterior_preflop_deviation(features: dict) -> dict:
    posterior = features.get("archetype_posterior") if isinstance(features, dict) else None
    if not isinstance(posterior, dict):
        posterior = {}
    bound = _float(features.get("deviation_bound") if isinstance(features, dict) else 0.0, 0.0)
    bound = min(max(0.0, bound), 4.0)

    open_shift = 0.0
    continue_shift = 0.0
    for label, weights in _ARCHETYPE_SHIFT_WEIGHTS.items():
        probability = max(0.0, _float(posterior.get(label), 0.0))
        open_shift += probability * weights["open"] * bound
        continue_shift += probability * weights["continue"] * bound

    open_shift = _cap(open_shift, -bound, bound)
    continue_shift = _cap(continue_shift, -bound, bound)
    total = abs(open_shift) + abs(continue_shift)
    if total > bound and total > 0.0:
        scale = bound / total
        open_shift *= scale
        continue_shift *= scale

    return {
        "open_shift_pp": open_shift,
        "continue_shift_pp": continue_shift,
        "deviation_bound_pp": bound,
    }


def _min_raise_action(game_state: dict) -> dict:
    amount = sizing_to_amount(
        "min_raise",
        game_state.get("pot", 0),
        game_state.get("your_stack", 0),
        game_state.get("min_raise_to", 0),
        game_state.get("your_bet_this_street", 0),
    )
    return {"action": "raise", "amount": amount}


def _within_shift(score: int, edge_score: int, shift_pp: float) -> bool:
    score_window = max(0.0, float(shift_pp)) * _SCORE_POINTS_PER_DEVIATION_PP
    return abs(float(score) - float(edge_score)) <= score_window


def _cap(value: float, low: float, high: float) -> float:
    return min(max(float(value), float(low)), float(high))


def _float(value, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def decide(game_state: dict) -> dict:
    """Return a legal action for the given game_state."""
    if isinstance(game_state, dict) and game_state.get("type") == "warmup":
        return {"action": "check"}
    try:
        if not isinstance(game_state, dict):
            return {"action": "fold"}
        return run_with_budget(
            lambda state: _legalize_action(state, _decide_core(state)),
            _safe_fallback,
            game_state,
        )
    except Exception:
        return {"action": "fold"}
