"""Behavior-only archetype posterior features.

The model deliberately ignores player names and archive labels. It derives a
small table-level posterior from public actions: how often non-hero seats
raise, move all-in, call, check, or fold across the rolling match log.

# Source: [[Libratus-Brown-Sandholm-2017]]
# Source: [[Engine-Fullhouse]]
"""

AGGRESSIVE_ACTIONS = ("raise", "all_in")
PASSIVE_ACTIONS = ("call", "check", "fold")
_MODELED_ACTIONS = ("raise", "all_in", "call", "fold", "check")

ARCHETYPE_LABELS = (
    "range_mc_pot_odds",
    "blueprint_threshold_exploit",
    "risk_gated_conservative",
    "stage_variant_anti_punt",
    "monte_carlo_basic",
)

MIN_ARCHETYPE_OBSERVATIONS = 20
FULL_CONFIDENCE_OBSERVATIONS = 220
MAX_DEVIATION_BOUND_PP = 4.0

# Calibrated from tools/archetypes/*/CALIBRATION.md static frequency tables,
# translated into the public action categories available in engine logs.
ARCHETYPE_ACTION_RATES = {
    "range_mc_pot_odds": {
        "raise": 0.22,
        "all_in": 0.01,
        "call": 0.42,
        "fold": 0.25,
        "check": 0.10,
    },
    "blueprint_threshold_exploit": {
        "raise": 0.33,
        "all_in": 0.01,
        "call": 0.18,
        "fold": 0.38,
        "check": 0.10,
    },
    "risk_gated_conservative": {
        "raise": 0.12,
        "all_in": 0.00,
        "call": 0.12,
        "fold": 0.64,
        "check": 0.12,
    },
    "stage_variant_anti_punt": {
        "raise": 0.26,
        "all_in": 0.00,
        "call": 0.24,
        "fold": 0.40,
        "check": 0.10,
    },
    "monte_carlo_basic": {
        "raise": 0.30,
        "all_in": 0.01,
        "call": 0.31,
        "fold": 0.29,
        "check": 0.09,
    },
}

_ACTION_RATE_WEIGHTS = {
    "raise": 1.20,
    "all_in": 1.60,
    "call": 1.10,
    "fold": 1.20,
    "check": 0.70,
}


class OpponentModel:
    """Stateless feature extractor over the engine's public action logs."""

    def archetype_features(self, game_state: dict) -> dict:
        hero_seat = _int(game_state.get("seat_to_act"), -1) if isinstance(game_state, dict) else -1
        actions = _observed_actions(game_state if isinstance(game_state, dict) else {})
        other_actions = [
            item for item in actions
            if item.get("seat") is not None and _int(item.get("seat"), -2) != hero_seat
        ]

        counts = {action: 0 for action in _MODELED_ACTIONS}
        for item in other_actions:
            action = str(item.get("action", "")).lower()
            if action in counts:
                counts[action] += 1

        total = sum(counts.values())
        rates = {
            action: counts[action] / max(1, total)
            for action in _MODELED_ACTIONS
        }
        posterior = _posterior_from_rates(rates, total)
        confidence = _sample_confidence(total)
        current_pressure = _current_pressure(game_state if isinstance(game_state, dict) else {}, hero_seat)

        raise_rate = rates["raise"]
        all_in_rate = rates["all_in"]
        fold_rate = rates["fold"]
        call_rate = rates["call"]
        aggression_rate = raise_rate + all_in_rate
        high_pressure = (
            (total >= MIN_ARCHETYPE_OBSERVATIONS and aggression_rate >= 0.42)
            or (total >= 4 and aggression_rate >= 0.70 and current_pressure["facing_raise"])
            or current_pressure["raise_count"] >= 2
        )
        fold_prone_pressure = (
            total >= MIN_ARCHETYPE_OBSERVATIONS
            and fold_rate >= 0.45
            and call_rate <= 0.25
        )
        top_label, top_probability = _top_posterior(posterior)

        return {
            "archetype_posterior": posterior,
            "n_observations": total,
            "deviation_bound": MAX_DEVIATION_BOUND_PP * confidence,
            "actions": total,
            "raises": counts["raise"],
            "all_ins": counts["all_in"],
            "calls": counts["call"],
            "checks": counts["check"],
            "folds": counts["fold"],
            "raise_rate": raise_rate,
            "all_in_rate": all_in_rate,
            "call_rate": call_rate,
            "check_rate": rates["check"],
            "fold_rate": fold_rate,
            "aggression_rate": aggression_rate,
            "facing_raise": current_pressure["facing_raise"],
            "high_pressure": high_pressure,
            "fold_prone_pressure": fold_prone_pressure,
            "top_archetype": top_label,
            "top_probability": top_probability,
            "posterior_debug": _posterior_debug(total, rates, top_label, top_probability, confidence),
        }

    def pressure_features(self, game_state: dict) -> dict:
        """Compatibility wrapper for callers still expecting pressure fields."""
        return self.archetype_features(game_state)


def _observed_actions(game_state: dict) -> list:
    match_log = game_state.get("match_action_log")
    if isinstance(match_log, list) and match_log:
        return _nonblind_action_items(match_log)
    action_log = game_state.get("action_log")
    if isinstance(action_log, list):
        return _nonblind_action_items(action_log)
    return []


def _nonblind_action_items(items: list) -> list:
    return [
        item for item in items
        if isinstance(item, dict)
        and str(item.get("action", "")).lower() not in ("small_blind", "big_blind")
    ]


def _posterior_from_rates(rates: dict, total: int) -> dict:
    uniform = _uniform_posterior()
    if total < MIN_ARCHETYPE_OBSERVATIONS:
        return uniform

    likelihoods = {}
    for label in ARCHETYPE_LABELS:
        target = ARCHETYPE_ACTION_RATES[label]
        distance = 0.0
        for action in _MODELED_ACTIONS:
            weight = _ACTION_RATE_WEIGHTS[action]
            distance += weight * abs(rates[action] - target[action])
        likelihoods[label] = 1.0 / max(0.01, distance)

    posterior = _normalize(likelihoods)
    confidence = _sample_confidence(total)
    return {
        label: uniform[label] * (1.0 - confidence) + posterior[label] * confidence
        for label in ARCHETYPE_LABELS
    }


def _sample_confidence(total: int) -> float:
    if total < MIN_ARCHETYPE_OBSERVATIONS:
        return 0.0
    span = max(1, FULL_CONFIDENCE_OBSERVATIONS - MIN_ARCHETYPE_OBSERVATIONS)
    return min(1.0, max(0.0, (total - MIN_ARCHETYPE_OBSERVATIONS) / span))


def _uniform_posterior() -> dict:
    value = 1.0 / len(ARCHETYPE_LABELS)
    return {label: value for label in ARCHETYPE_LABELS}


def _normalize(values: dict) -> dict:
    total = sum(max(0.0, float(values.get(label, 0.0))) for label in ARCHETYPE_LABELS)
    if total <= 0.0:
        return _uniform_posterior()
    return {
        label: max(0.0, float(values.get(label, 0.0))) / total
        for label in ARCHETYPE_LABELS
    }


def _top_posterior(posterior: dict) -> tuple:
    top_label = ARCHETYPE_LABELS[0]
    top_probability = float(posterior.get(top_label, 0.0))
    for label in ARCHETYPE_LABELS[1:]:
        probability = float(posterior.get(label, 0.0))
        if probability > top_probability:
            top_label = label
            top_probability = probability
    return top_label, top_probability


def _posterior_debug(total: int, rates: dict, top_label: str, top_probability: float, confidence: float) -> str:
    rate_bits = [f"{action}={rates[action]:.2f}" for action in _MODELED_ACTIONS]
    return (
        f"n={total};top={top_label}:{top_probability:.2f};"
        f"confidence={confidence:.2f};" + ",".join(rate_bits)
    )


def _current_pressure(game_state: dict, hero_seat: int) -> dict:
    raise_count = 0
    for item in game_state.get("action_log") or []:
        if not isinstance(item, dict):
            continue
        seat = _int(item.get("seat"), -2)
        action = str(item.get("action", "")).lower()
        if seat != hero_seat and action in AGGRESSIVE_ACTIONS:
            raise_count += 1
    return {
        "raise_count": raise_count,
        "facing_raise": bool(game_state.get("amount_owed")) and raise_count > 0,
    }


def _int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
