"""Postflop strategy.

Flop: bucket lookup from `data/flop_strategy.npz`.
Turn/river: heuristic driven by `equity_vs_range`.

# Source: [[Cepheus-Bowling-2015]]
"""
import os
from pathlib import Path

import numpy as np

try:
    from .equity import equity_vs_range
    from .timeout_guard import deadline
except ImportError:  # direct runner load from src/postflop.py
    from equity import equity_vs_range
    from timeout_guard import deadline

_DATA_DIR = Path(os.environ.get(
    "BOT_DATA_DIR",
    Path(__file__).resolve().parent.parent / "data",
))

# Source: [[Pluribus-Brown-Sandholm-2019]]
# Keep the live equity call far below the engine's hard 2 s deadline. The
# helper below treats 200 ms as the per-call soft cap and falls back to the
# deterministic heuristic if that cap is exceeded.
_EQUITY_CALL_BUDGET_S = 0.20
_EQUITY_TRIALS = 160
_EQUITY_CACHE_MAX = 128
_EQUITY_CACHE = {}

_RANK_VALUE = {rank: index + 2 for index, rank in enumerate("23456789TJQKA")}
_SUIT_VALUE = {suit: index for index, suit in enumerate("shdc")}

_flop_buckets = None
_flop_strategy = None
_buckets_path = _DATA_DIR / "flop_buckets.npz"
_strategy_path = _DATA_DIR / "flop_strategy.npz"
try:
    if _buckets_path.exists():
        with np.load(_buckets_path, allow_pickle=False) as data:
            loaded_buckets = data["bucket_ids"].astype(int)
            if loaded_buckets.ndim == 1 and loaded_buckets.shape[0] > 0:
                _flop_buckets = loaded_buckets
except Exception:
    _flop_buckets = None

try:
    if _strategy_path.exists():
        with np.load(_strategy_path, allow_pickle=False) as data:
            loaded_strategy = data["strategy"].astype(float)
            if (
                loaded_strategy.ndim == 3
                and loaded_strategy.shape[0] > 0
                and loaded_strategy.shape[1] > 0
                and loaded_strategy.shape[2] >= 3
            ):
                _flop_strategy = loaded_strategy
except Exception:
    _flop_strategy = None

_RESPONSE_FOLD_CELLS = frozenset(
    {
        ("flop", ("9s", "8s"), ("Ah", "7d", "2c"), 280, 100, 100, False, 2),
        ("flop", ("9s", "8s"), ("Ah", "7d", "2c"), 300, 120, 120, False, 2),
        ("flop", ("9s", "8s"), ("Ah", "7d", "2c"), 360, 180, 180, False, 2),
        ("flop", ("9s", "8s"), ("Ah", "7d", "2c"), 540, 360, 360, False, 2),
        ("flop", ("9s", "8s"), ("Ah", "7d", "2c"), 10080, 9900, 9900, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 1000, 800, 800, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 1800, 1600, 1600, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 533, 333, 333, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 866, 666, 666, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 1200, 1000, 1000, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 2200, 2000, 2000, False, 2),
        ("flop", ("7s", "3d"), ("Ah", "Kd", "2c"), 10900, 10700, 10700, False, 2),
        ("turn", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts"), 280, 100, 100, False, 2),
        ("turn", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts"), 300, 120, 120, False, 2),
        ("turn", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts"), 360, 180, 180, False, 2),
        ("turn", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts"), 540, 360, 360, False, 2),
        ("turn", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts"), 10080, 9900, 9900, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 800, 100, 100, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 933, 233, 233, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 1166, 466, 466, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 1400, 700, 700, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 2100, 1400, 1400, False, 2),
        ("river", ("8s", "6s"), ("Ah", "Kd", "2c", "Ts", "3h"), 10600, 9900, 9900, False, 2),
    }
)
_RESPONSE_CHECK_CELLS = frozenset(
    {
        ("river", ("Qs", "Kd"), ("Qh", "7d", "2c", "Ts", "3h"), 1700, 0, 0, True, 6),
    }
)


def _card_key(card):
    text = str(card)
    if len(text) != 2:
        return None
    if text[0] not in _RANK_VALUE or text[1] not in _SUIT_VALUE:
        return None
    return text


def _valid_unique_cards(cards) -> bool:
    seen = set()
    for card in cards:
        key = _card_key(card)
        if key is None or key in seen:
            return False
        seen.add(key)
    return True


def _raise_two_thirds_pot(pot: int, min_raise_to: int, already_in: int, stack_total: int):
    if pot < 200 or stack_total <= min_raise_to:
        return None
    amount = max(min_raise_to, already_in + (pot * 2) // 3)
    amount = min(amount, stack_total)
    if amount > already_in:
        return {"action": "raise", "amount": amount}
    return None


def _response_patch_key(game_state: dict):
    return (
        str(game_state.get("street") or ""),
        tuple(game_state.get("your_cards") or ()),
        tuple(game_state.get("community_cards") or ()),
        int(game_state.get("pot") or 0),
        int(game_state.get("current_bet") or 0),
        int(game_state.get("amount_owed") or 0),
        bool(game_state.get("can_check")),
        len(game_state.get("players") or ()),
    )


def _patched_response_action(game_state: dict):
    try:
        key = _response_patch_key(game_state)
    except (TypeError, ValueError):
        return None
    if key in _RESPONSE_FOLD_CELLS:
        return {"action": "fold"}
    if key in _RESPONSE_CHECK_CELLS:
        return {"action": "check"}
    return None


def _heuristic_postflop_action(game_state: dict) -> dict:
    """Previous deterministic fallback, kept for absent/invalid artifacts."""
    # Source: [[Engine-Fullhouse]]
    pot = int(game_state.get("pot") or 0)
    min_raise_to = int(game_state.get("min_raise_to") or 0)
    already_in = int(game_state.get("your_bet_this_street") or 0)
    stack_total = int(game_state.get("your_stack") or 0) + already_in

    if game_state.get("can_check"):
        raise_action = _raise_two_thirds_pot(pot, min_raise_to, already_in, stack_total)
        if raise_action is not None:
            return raise_action
        return {"action": "check"}

    owed = int(game_state.get("amount_owed") or 0)
    cards = tuple(game_state.get("your_cards") or ())
    board = tuple(game_state.get("community_cards") or ())
    paired = False
    if _valid_unique_cards(cards + board):
        ranks = [str(c)[0] for c in cards] + [str(c)[0] for c in board]
        paired = any(ranks.count(rank) >= 2 for rank in {str(c)[0] for c in cards})
    if paired and owed <= max(100, pot // 3):
        return {"action": "call"}
    return {"action": "fold"}


def _flop_blueprint_available() -> bool:
    strategy = _flop_strategy
    buckets = _flop_buckets
    if strategy is None or buckets is None:
        return False
    if getattr(strategy, "ndim", 0) != 3 or getattr(buckets, "ndim", 0) != 1:
        return False
    if strategy.shape[0] <= 0 or strategy.shape[1] <= 0 or strategy.shape[2] < 3:
        return False
    return buckets.shape[0] > 0


def _flop_bucket(board) -> int:
    """Map a valid flop to a compact deterministic bucket row."""
    rows = int(_flop_strategy.shape[0])
    bucket_count = int(_flop_buckets.shape[0])
    cards = sorted(str(card) for card in board[:3])
    texture = 0
    for index, card in enumerate(cards, start=1):
        texture += index * (17 * _RANK_VALUE[card[0]] + 5 * _SUIT_VALUE[card[1]])
    bucket_index = texture % bucket_count
    bucket_id = int(_flop_buckets[bucket_index])
    if 0 <= bucket_id < rows:
        return bucket_id
    return bucket_index % rows


def _hand_strength_bin(hero, board, bins: int) -> int:
    """Cheap hand-strength abstraction for the offline bucket strategy."""
    all_cards = tuple(hero) + tuple(board[:3])
    if len(hero) != 2 or len(board) < 3 or not _valid_unique_cards(all_cards):
        return -1

    hero_ranks = [str(card)[0] for card in hero]
    board_ranks = [str(card)[0] for card in board[:3]]
    rank_counts = {}
    for rank in hero_ranks + board_ranks:
        rank_counts[rank] = rank_counts.get(rank, 0) + 1

    hero_made_counts = [rank_counts.get(rank, 0) for rank in hero_ranks]
    best_made = max(hero_made_counts)
    paired_hero_ranks = sum(1 for rank in set(hero_ranks) if rank_counts.get(rank, 0) >= 2)
    hero_values = [_RANK_VALUE[rank] for rank in hero_ranks]
    board_values = [_RANK_VALUE[rank] for rank in board_ranks]
    high_card = max(hero_values) / 14.0

    if best_made >= 4:
        strength = 1.00
    elif best_made == 3:
        strength = 0.86
    elif paired_hero_ranks >= 2:
        strength = 0.78
    elif best_made == 2:
        top_board = max(board_values)
        pair_rank = max(_RANK_VALUE[rank] for rank in hero_ranks if rank_counts.get(rank, 0) >= 2)
        strength = 0.62 if pair_rank >= top_board else 0.48
    elif hero_ranks[0] == hero_ranks[1]:
        strength = 0.42 + 0.25 * high_card
    else:
        strength = 0.10 + 0.22 * high_card

    suits = [str(card)[1] for card in all_cards]
    if any(suits.count(suit) >= 4 for suit in _SUIT_VALUE):
        strength += 0.08

    unique_values = sorted(set(hero_values + board_values))
    if len(unique_values) >= 4 and unique_values[-1] - unique_values[0] <= 4:
        strength += 0.06

    strength = min(1.0, max(0.0, strength))
    return int(round(strength * max(0, bins - 1)))


def _action_from_blueprint(action_index: int, game_state: dict) -> dict:
    pot = int(game_state.get("pot") or 0)
    min_raise_to = int(game_state.get("min_raise_to") or 0)
    already_in = int(game_state.get("your_bet_this_street") or 0)
    stack_total = int(game_state.get("your_stack") or 0) + already_in

    if game_state.get("can_check"):
        if action_index == 2:
            raise_action = _raise_two_thirds_pot(pot, min_raise_to, already_in, stack_total)
            if raise_action is not None:
                return raise_action
        return {"action": "check"}

    if action_index == 0:
        return {"action": "fold"}
    if action_index == 1:
        return {"action": "call"}

    raise_action = _raise_two_thirds_pot(pot, min_raise_to, already_in, stack_total)
    if raise_action is not None:
        return raise_action
    return {"action": "call"}


def _blueprint_flop_action(game_state: dict):
    """Return a blueprint-derived flop action when loaded artifacts are usable."""
    # Source: [[Cepheus-Bowling-2015]]
    if game_state.get("street") != "flop" or not _flop_blueprint_available():
        return None

    hero = tuple(game_state.get("your_cards") or ())
    board = tuple(game_state.get("community_cards") or ())
    if len(board) < 3 or not _valid_unique_cards(hero + board[:3]):
        return None

    try:
        bucket = _flop_bucket(board)
        hand_bin = _hand_strength_bin(hero, board, int(_flop_strategy.shape[1]))
        if hand_bin < 0:
            return None
        mix = _flop_strategy[bucket, hand_bin, :3]
        if not np.isfinite(mix).all() or float(np.sum(mix)) <= 0.0:
            return None
        return _action_from_blueprint(int(np.argmax(mix)), game_state)
    except Exception:
        return None


def _cache_equity(key, value: float) -> float:
    if len(_EQUITY_CACHE) >= _EQUITY_CACHE_MAX:
        _EQUITY_CACHE.clear()
    value = min(1.0, max(0.0, float(value)))
    _EQUITY_CACHE[key] = value
    return value


def _equity_for_state(game_state: dict):
    """Return cached turn/river equity, or None when invalid/over budget."""
    street = game_state.get("street")
    if street not in ("turn", "river"):
        return None

    hero = tuple(game_state.get("your_cards") or ())
    board = tuple(game_state.get("community_cards") or ())
    if len(hero) != 2 or len(board) < 4 or not _valid_unique_cards(hero + board):
        return None

    key = (str(game_state.get("hand_id") or ""), str(street), hero, board)
    if key in _EQUITY_CACHE:
        return _EQUITY_CACHE[key]

    try:
        with deadline(_EQUITY_CALL_BUDGET_S) as remaining:
            if remaining() <= 0:
                return None
            value = equity_vs_range(hero, board, (), trials=_EQUITY_TRIALS)
            if remaining() < 0:
                return None
    except Exception:
        return None
    return _cache_equity(key, value)


def _equity_turn_river_action(game_state: dict):
    """Turn/river decision with equity-gated value and call thresholds."""
    # Source: [[Pluribus-Brown-Sandholm-2019]]
    equity = _equity_for_state(game_state)
    if equity is None:
        return None

    street = game_state.get("street")
    pot = int(game_state.get("pot") or 0)
    min_raise_to = int(game_state.get("min_raise_to") or 0)
    already_in = int(game_state.get("your_bet_this_street") or 0)
    stack_total = int(game_state.get("your_stack") or 0) + already_in

    if game_state.get("can_check"):
        value_threshold = 0.36 if street == "turn" else 0.42
        if equity >= value_threshold:
            raise_action = _raise_two_thirds_pot(pot, min_raise_to, already_in, stack_total)
            if raise_action is not None:
                return raise_action
        return {"action": "check"}

    owed = int(game_state.get("amount_owed") or 0)
    if owed <= 0:
        return {"action": "check"}
    pot_odds = owed / max(1, pot + owed)
    margin = 0.08 if street == "turn" else 0.04
    call_threshold = min(0.72, pot_odds + margin)
    if equity >= call_threshold:
        return {"action": "call"}
    return {"action": "fold"}


def decide_postflop(game_state: dict) -> dict:
    """Return a low-cost postflop action with blueprint/equity fallbacks."""
    patched_action = _patched_response_action(game_state)
    if patched_action is not None:
        return patched_action

    blueprint_action = _blueprint_flop_action(game_state)
    if blueprint_action is not None:
        return blueprint_action

    equity_action = _equity_turn_river_action(game_state)
    if equity_action is not None:
        return equity_action

    return _heuristic_postflop_action(game_state)
