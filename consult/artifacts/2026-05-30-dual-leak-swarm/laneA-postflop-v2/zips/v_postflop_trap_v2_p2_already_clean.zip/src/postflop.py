"""Postflop strategy.

Flop: bucket lookup from `data/flop_strategy.npz`.
Turn/river: heuristic driven by `equity_vs_range` + `opponent_model`.

# Source: [[Cepheus-Bowling-2015]]
"""
import os
from pathlib import Path

import numpy as np

_DATA_DIR = Path(os.environ.get(
    "BOT_DATA_DIR",
    Path(__file__).resolve().parent.parent / "data",
))

_flop_buckets = None
_flop_strategy = None
_buckets_path = _DATA_DIR / "flop_buckets.npz"
_strategy_path = _DATA_DIR / "flop_strategy.npz"
if _buckets_path.exists():
    with np.load(_buckets_path, allow_pickle=False) as data:
        _flop_buckets = data["bucket_ids"].astype(int)
if _strategy_path.exists():
    with np.load(_strategy_path, allow_pickle=False) as data:
        _flop_strategy = data["strategy"].astype(float)

_RANKS = "23456789TJQKA"
_RANK_VALUE = {rank: idx for idx, rank in enumerate(_RANKS, start=2)}


def _rank(card) -> str:
    text = str(card or "")
    return text[0] if text else ""


def _suit(card) -> str:
    text = str(card or "")
    return text[1:2] if len(text) > 1 else ""


def _counts(items) -> dict:
    out = {}
    for item in items:
        if item:
            out[item] = out.get(item, 0) + 1
    return out


def _board_texture(board: list) -> tuple[bool, bool, bool]:
    ranks = [_rank(card) for card in board if card]
    suits = [_suit(card) for card in board if card]
    rank_counts = _counts(ranks)
    suit_counts = _counts(suits)
    paired = any(count >= 2 for count in rank_counts.values())
    max_suit = max(suit_counts.values()) if suit_counts else 0
    two_tone = bool(suits) and 2 <= max_suit < len(suits)
    values = sorted(_RANK_VALUE.get(rank, 0) for rank in ranks)
    static = len(values) < 3 or values[-1] - values[0] > 5
    return paired, two_tone, static


def _has_straight(cards: list, board: list) -> bool:
    values = {_RANK_VALUE.get(_rank(card), 0) for card in cards + board}
    values.discard(0)
    if 14 in values:
        values.add(1)
    hero_values = {_RANK_VALUE.get(_rank(card), 0) for card in cards}
    if 14 in hero_values:
        hero_values.add(1)
    for start in range(1, 11):
        run = set(range(start, start + 5))
        if run.issubset(values) and run.intersection(hero_values):
            return True
    return False


def _clear_river_value(cards: list, board: list) -> bool:
    hero_ranks = [_rank(card) for card in cards if card]
    all_ranks = [_rank(card) for card in cards + board if card]
    counts = _counts(all_ranks)
    if any(counts.get(rank, 0) >= 3 for rank in hero_ranks):
        return True

    if len(hero_ranks) == 2 and hero_ranks[0] == hero_ranks[1]:
        board_paired = any(count >= 2 for count in _counts([_rank(card) for card in board]).values())
        if board_paired or _RANK_VALUE.get(hero_ranks[0], 0) >= 10:
            return True

    hero_suits = {_suit(card) for card in cards if card}
    all_suits = _counts([_suit(card) for card in cards + board if card])
    if any(suit and all_suits.get(suit, 0) >= 5 for suit in hero_suits):
        return True

    return _has_straight(cards, board)


def decide_postflop(game_state: dict) -> dict:
    """Return a low-cost postflop action for the G2 deterministic baseline."""
    # Source: [[Engine-Fullhouse]]
    street = game_state.get("street")
    pot = int(game_state.get("pot") or 0)
    min_raise_to = int(game_state.get("min_raise_to") or 0)
    already_in = int(game_state.get("your_bet_this_street") or 0)
    stack_total = int(game_state.get("your_stack") or 0) + already_in
    cards = game_state.get("your_cards") or []
    board = game_state.get("community_cards") or []

    if game_state.get("can_check"):
        if street == "river":
            _, two_tone, static = _board_texture(board)
            if two_tone and static and not _clear_river_value(cards, board):
                return {"action": "check"}
        if pot >= 200 and stack_total > min_raise_to:
            amount = max(min_raise_to, already_in + (pot * 2) // 3)
            amount = min(amount, stack_total)
            if amount > already_in:
                return {"action": "raise", "amount": amount}
        return {"action": "check"}

    owed = int(game_state.get("amount_owed") or 0)
    if street == "river" and already_in > 0:
        board_paired, two_tone, static = _board_texture(board)
        if board_paired and two_tone and static and _clear_river_value(cards, board):
            return {"action": "call"}

    ranks = [str(c)[0] for c in cards if c] + [str(c)[0] for c in board if c]
    paired = any(ranks.count(rank) >= 2 for rank in {str(c)[0] for c in cards if c})
    if paired and owed <= max(100, pot // 3):
        return {"action": "call"}
    return {"action": "fold"}
