"""Preflop blueprint lookup.

Loads `data/preflop_blueprint.npz` eagerly at module import (covered by the
engine's 30 s warmup). Returns action + sizing for (position, hand, action_seq).

# Source: [[Pluribus-Brown-Sandholm-2019]]
# Source: [[MCCFR-Lanctot-2009]]
"""
import os
from pathlib import Path

import numpy as np

try:
    from src.ranges import RANK_VALUE, STRONG_CONTINUE, hand_score
except ImportError:  # direct runner load from src/preflop_lookup.py
    from ranges import RANK_VALUE, STRONG_CONTINUE, hand_score

_DATA_DIR = Path(os.environ.get(
    "BOT_DATA_DIR",
    Path(__file__).resolve().parent.parent / "data",
))
_BLUEPRINT_PATH = _DATA_DIR / "preflop_blueprint.npz"
_BIG_BLIND_FALLBACK = 100
_PREMIUM_HU_BB_3BET = frozenset({"AA", "KK", "QQ", "JJ", "AKs", "AKo", "AQs", "AQo"})

_SCORES = {}
if _BLUEPRINT_PATH.exists():
    with np.load(_BLUEPRINT_PATH, allow_pickle=False) as data:
        hands = data["hands"].astype(str)
        scores = data["scores"].astype(int)
        _SCORES = {hand: int(score) for hand, score in zip(hands, scores)}


def _to_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _raise_count(actions: tuple) -> int:
    # Count raises, not total voluntary actions: HU BB defense should trigger
    # on exactly a button open, not on limp/call clutter.
    return sum(1 for action in actions if action in ("raise", "all_in"))


def _hand_shape(hand_key: str) -> dict:
    if not hand_key or len(hand_key) < 2:
        return {"high": 0, "low": 0, "pair": False, "suited": False, "gap": 99}
    high = RANK_VALUE.get(hand_key[0], 0)
    low = RANK_VALUE.get(hand_key[1], 0)
    pair = hand_key[0] == hand_key[1]
    suited = (not pair) and hand_key.endswith("s")
    gap = 0 if pair else max(0, high - low - 1)
    return {"high": high, "low": low, "pair": pair, "suited": suited, "gap": gap}


def _hu_bb_vs_button_open(voluntary: tuple) -> bool:
    if _raise_count(voluntary) != 1:
        return False
    # A single heads-up open should be raise-only. A call means limp/iso or a
    # multiway abstraction, which must stay on the old six-max-safe path.
    return not any(action == "call" for action in voluntary)


def _hu_bb_defense(
    hand_key: str,
    score: int,
    *,
    amount_owed=None,
    pot=None,
    current_bet=None,
    min_raise_to=None,
    your_stack=None,
    your_bet_this_street=None,
) -> dict:
    """Heads-up BB response to a button open.

    This is deliberately local: premiums 3-bet, medium/playable hands call at
    normal prices, suited/connective hands defend only when cheap, and trash
    folds. It avoids the prior failed button-open tightening and never jams
    medium hands into a single open.
    """
    owed = max(0, _to_int(amount_owed))
    pot_now = max(0, _to_int(pot))
    current = max(0, _to_int(current_bet))
    already_in = max(0, _to_int(your_bet_this_street))
    stack = max(0, _to_int(your_stack))
    posted_bb = already_in if already_in > 0 else _BIG_BLIND_FALLBACK
    open_size_bb = current / max(1, posted_bb)
    call_price = owed / max(1, pot_now + owed)
    stack_to_pot = stack / max(1, pot_now)
    shape = _hand_shape(hand_key)
    pair = shape["pair"]
    suited = shape["suited"]
    connected = shape["gap"] <= 1 and shape["high"] >= 7 and shape["low"] >= 5
    suited_connective = suited and shape["gap"] <= 2 and shape["high"] >= 7 and shape["low"] >= 4
    cheap_open = open_size_bb <= 3.0 and call_price <= 0.33
    fair_open = open_size_bb <= 4.0 and call_price <= 0.38
    big_open = open_size_bb >= 6.0 or call_price >= 0.45

    if score >= 92 or hand_key in _PREMIUM_HU_BB_3BET:
        if owed and stack and owed >= (stack * 3) // 5:
            return {"action": "all_in", "reason": "hu_bb_premium_stackoff"}
        sizing = "pot" if not big_open else "min_raise"
        return {"action": "raise", "sizing": sizing, "reason": "hu_bb_premium_3bet"}

    # Strong but non-premium hands realize enough equity heads-up; keep them
    # out of the pressure overlay's medium all-in path.
    if hand_key in STRONG_CONTINUE or score >= 84:
        if not big_open or owed <= max(300, stack // 8):
            return {"action": "call", "reason": "hu_bb_strong_flat"}
        return {"action": "fold", "reason": "hu_bb_strong_price_fold"}

    # Medium broadways and pairs call normal min/small opens, but do not jam.
    if score >= 70 and fair_open:
        return {"action": "call", "reason": "hu_bb_medium_flat"}

    # Cheap set-mining / suited-connective defense only; this protects six-max
    # and large-open regressions by price-gating speculative hands.
    if pair and cheap_open and stack_to_pot >= 8.0:
        return {"action": "call", "reason": "hu_bb_pair_price_defend"}
    if (suited_connective or (suited and connected)) and cheap_open and stack_to_pot >= 7.0:
        return {"action": "call", "reason": "hu_bb_suited_connective_defend"}

    return {"action": "fold", "reason": "hu_bb_trash_or_price_fold"}


def lookup(
    position: str,
    hand: tuple,
    action_seq: tuple,
    *,
    amount_owed=None,
    pot=None,
    current_bet=None,
    min_raise_to=None,
    your_stack=None,
    your_bet_this_street=None,
):
    """Return blueprint action for the given preflop context, or None if not covered."""
    hand_key = "".join(hand) if isinstance(hand, tuple) else str(hand or "")
    score = _SCORES.get(hand_key, hand_score(hand_key))
    voluntary = tuple(a for a in action_seq if a not in ("small_blind", "big_blind"))
    raise_count = _raise_count(voluntary)
    facing_aggression = raise_count > 0

    if not facing_aggression:
        if position in ("heads_up_button", "small_blind", "button"):
            return {"action": "raise", "sizing": "min_raise", "reason": "heads_up_steal"}
        if position == "big_blind":
            return {"action": "check", "reason": "free_option"}
        if score >= 58:
            return {"action": "raise", "sizing": "min_raise", "reason": "range_open"}
        return {"action": "fold", "reason": "range_fold"}

    if position == "big_blind" and _hu_bb_vs_button_open(voluntary):
        posted_bb = max(1, _to_int(your_bet_this_street, _BIG_BLIND_FALLBACK) or _BIG_BLIND_FALLBACK)
        open_size_bb = max(0, _to_int(current_bet)) / posted_bb
        if open_size_bb <= 2.05:
            return _hu_bb_defense(
                hand_key,
                score,
                amount_owed=amount_owed,
                pot=pot,
                current_bet=current_bet,
                min_raise_to=min_raise_to,
                your_stack=your_stack,
                your_bet_this_street=your_bet_this_street,
            )

    if hand_key in STRONG_CONTINUE or score >= 86:
        return {"action": "call", "reason": "strong_continue"}
    if score >= 76 and len(voluntary) <= 1:
        return {"action": "call", "reason": "priced_continue"}
    return {"action": "fold", "reason": "dominated_vs_aggression"}
