"""PokerBot — `decide(game_state) -> dict`.

Schema and return shapes are documented in `docs/api-cheatsheet.md`; ground
truth lives in `ext/fullhouse-engine/sandbox/validator.py::TEST_STATES`.

The shipped archive places a tiny shim at `bot.py` (archive root) that does
`from src.bot import decide`. Heavy loads (blueprints, eval7 LUTs) happen at
module import — the engine's one-shot 30 s warmup call covers them so live
2 s decisions stay fast.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

DATA_DIR = os.environ.get(
    "BOT_DATA_DIR",
    os.path.join(os.path.dirname(_HERE), "data"),
)

# Codex wires these during G2/G3:
# from src.preflop_lookup import lookup as _preflop_lookup
# from src.postflop import decide_postflop as _decide_postflop
try:
    from src.timeout_guard import run_with_budget
except ImportError:  # direct runner load from src/bot.py
    from timeout_guard import run_with_budget

_VALID_ACTIONS = {"fold", "check", "call", "raise", "all_in"}


def _safe_fallback(game_state: dict) -> dict:
    """Last-resort legal action. Never raises."""
    if isinstance(game_state, dict) and game_state.get("can_check"):
        return {"action": "check"}
    return {"action": "fold"}


def _legalize_action(game_state: dict, raw_action: dict) -> dict:
    """Normalize strategy output to one of the engine's valid action shapes."""
    # Source: [[Engine-Fullhouse]]
    if not isinstance(game_state, dict) or not isinstance(raw_action, dict):
        return _safe_fallback(game_state)

    action = str(raw_action.get("action", "")).lower().strip()
    if action not in _VALID_ACTIONS:
        return _safe_fallback(game_state)

    if action == "check":
        if game_state.get("can_check"):
            return {"action": "check"}
        return {"action": "call"}

    if action == "call":
        if game_state.get("can_check"):
            return {"action": "check"}
        return {"action": "call"}

    if action == "raise":
        try:
            amount = int(raw_action.get("amount"))
        except (TypeError, ValueError):
            return _safe_fallback(game_state)
        min_raise_to = int(game_state.get("min_raise_to") or 0)
        stack_total = int(game_state.get("your_stack") or 0) + int(
            game_state.get("your_bet_this_street") or 0
        )
        if stack_total <= 0:
            return _safe_fallback(game_state)
        amount = max(amount, min_raise_to)
        if amount >= stack_total:
            return {"action": "all_in"}
        return {"action": "raise", "amount": amount}

    if action == "all_in":
        return {"action": "all_in"}

    return {"action": "fold"}


def _decide_core(game_state: dict) -> dict:
    """Fast G1 baseline. G2/G3 replace this with strategy routing."""
    return _safe_fallback(game_state)


def decide(game_state: dict) -> dict:
    """Return a legal action for the given game_state.

    Wired through G1-G3 by Codex.
    """
    if isinstance(game_state, dict) and game_state.get("type") == "warmup":
        return {"action": "check"}
    try:
        if not isinstance(game_state, dict):
            return {"action": "fold"}
        return run_with_budget(
            lambda state: _legalize_action(state, _decide_core(state)),
            _safe_fallback,
            game_state,
        )
    except Exception:
        return {"action": "fold"}
