"""Per-seat opponent frequency tracker.

Tracks VPIP, PFR, AF (aggression factor), FoldToCBet. Exploit shifts apply
only after a 30-hand warmup per seat — before that, use baseline frequencies.

# Source: [[Libratus-Brown-Sandholm-2017]]
# Source: [[Engine-Fullhouse]]
"""
WARMUP_HANDS = 30


class OpponentModel:
    """Rolling counters per seat. Updated from each hand's action_log."""

    def __init__(self):
        self._seats = {}

    def _seat(self, seat_id: int) -> dict:
        return self._seats.setdefault(
            int(seat_id),
            {
                "hands": 0,
                "vpip": 0,
                "pfr": 0,
                "aggressive": 0,
                "calls": 0,
                "fold_to_cbet": 0,
                "cbet_faced": 0,
            },
        )

    def observe_hand(self, hand_event: dict) -> None:
        """Update counters from a completed-hand event."""
        actions = hand_event.get("action_log") if isinstance(hand_event, dict) else None
        if not actions:
            return
        seats = {
            int(item.get("seat"))
            for item in actions
            if isinstance(item, dict) and item.get("seat") is not None
        }
        for seat_id in seats:
            self._seat(seat_id)["hands"] += 1

        preflop_seen = set()
        preflop_raise_seen = set()
        last_preflop = True
        cbet_seat = None
        for item in actions:
            if not isinstance(item, dict):
                continue
            seat_id = item.get("seat")
            action = str(item.get("action", "")).lower()
            if seat_id is None:
                continue
            stats = self._seat(int(seat_id))
            if action in ("call", "raise", "all_in") and last_preflop:
                preflop_seen.add(int(seat_id))
            if action in ("raise", "all_in") and last_preflop:
                preflop_raise_seen.add(int(seat_id))
            if action in ("raise", "all_in"):
                stats["aggressive"] += 1
                if not last_preflop and cbet_seat is None:
                    cbet_seat = int(seat_id)
            if action == "call":
                stats["calls"] += 1
            if action == "fold" and cbet_seat is not None and int(seat_id) != cbet_seat:
                stats["fold_to_cbet"] += 1
                stats["cbet_faced"] += 1
            if action not in ("small_blind", "big_blind") and last_preflop is True:
                # The flat action log omits street labels; the first post-blind
                # raise/call/fold sequence is the only preflop segment we infer.
                last_preflop = True

        for seat_id in preflop_seen:
            self._seat(seat_id)["vpip"] += 1
        for seat_id in preflop_raise_seen:
            self._seat(seat_id)["pfr"] += 1

    def is_warm_for(self, seat_id: int) -> bool:
        return self._seat(seat_id)["hands"] >= WARMUP_HANDS

    def features(self, seat_id: int) -> dict:
        """Return {vpip, pfr, af, fold_to_cbet} for the given seat."""
        stats = self._seat(seat_id)
        hands = max(1, stats["hands"])
        calls = max(1, stats["calls"])
        faced = max(1, stats["cbet_faced"])
        return {
            "vpip": stats["vpip"] / hands,
            "pfr": stats["pfr"] / hands,
            "af": stats["aggressive"] / calls,
            "fold_to_cbet": stats["fold_to_cbet"] / faced,
        }
